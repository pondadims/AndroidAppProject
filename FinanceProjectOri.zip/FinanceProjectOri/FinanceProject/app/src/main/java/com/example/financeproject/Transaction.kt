package com.example.financeproject

data class Transaction(val label: String, val amount: Double, val description : String = "") {
}