package com.example.financeproject

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.financeproject.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.Locale


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var transactions: List<Transaction>
    private lateinit var transactionAdapter: TransactionAdapter
    private lateinit var linearLayoutManager: LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        transactions = arrayListOf(
            Transaction("Weekend Budget", 4000000.00, "Description 1"),
            Transaction("Samild", -30000.00, "Description 2"),
            Transaction("Bensin", -20000.00, "Description 3"),
            Transaction("Makan Padang", -25000.00, "Description 4"),
            Transaction("Marlong", -40000.00, "Description 5")
        ).toList()

        transactionAdapter = TransactionAdapter(transactions)
        linearLayoutManager = LinearLayoutManager(this)

        binding.recyclerview.apply {
            adapter = transactionAdapter
            layoutManager = linearLayoutManager
        }

        updateDashboard()

        binding.addBtn.setOnClickListener {
            goToAddTransactionActivity()
        }

    }

    private fun goToAddTransactionActivity() {
        val intent = Intent(this, AddTransactionActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun updateDashboard() {
        val totalAmount = transactions.map { it.amount }.sum()
        val budgetAmount = transactions.filter { it.amount > 0 }.map { it.amount }.sum()
        val expenseAmount = totalAmount - budgetAmount

        val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
        val formattedTotalAmount = formatter.format(totalAmount)
        val formattedBudgetAmount = formatter.format(budgetAmount)
        val formattedExpenseAmount = formatter.format(expenseAmount)

        binding.balance.text = formattedTotalAmount
        binding.budget.text = formattedBudgetAmount
        binding.expense.text = formattedExpenseAmount
    }
}

